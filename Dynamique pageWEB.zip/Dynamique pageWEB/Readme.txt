Name: Dynamique pageWEB 
Author: Marouane Belmallem
Type: HTML file
Languages: HTML,css and js

-------------------------------------------------------


Hello !

To test some my web design knowledge, icreated this small project that change the style with
changing the page size.

It has some funny assets, so enjoy with it.