function maketable(row,col){
    var table ="<table border='1 width='100%'>";
    var  ligne = document.row.input.value;
    var colonne= document.col.input.value;
    alert("vous avez tapez"+ligne+colonne);
    
}

var box = document.queryselector('.box')
box.innerHTML = maketable();