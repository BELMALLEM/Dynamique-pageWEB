function dudt = ddtshallow(~,u)
    g = 9.8;
    n = length(u) /2;
    dx = 1/n;
    h = u(1:n);
    v = u(n+1:end) ./ h;
    F1 = h.*v;
    F2 = h.*v.^2 + h.^2/2*g;
    nu = (abs(v) + sqrt(h*g)) * dx / 2;
    nu_interface = max(nu(1:end-1), nu(2:end));
    F1_interface = 0.5* (F1(1:end-1) + F1(2:end)) + ...
        nu_interface.* (h(1:end-1) - h(2:end)) / dx;
    u2 = h.*v;
    F2_interface = 0.5* (F2(1:end-1) + F2(2:end)) + ...
        nu_interface.* (u2(1:end-1) - u2(2:end)) / dx;
    F1_interface = [0; F1_interface; 0];
    F2_interface = [h(1).^2/2*g; F2_interface; h(end).^2/2*g];
    dudt = [(F1_interface(1:end-1) - F1_interface(2:end)) / dx;
            (F2_interface(1:end-1) - F2_interface(2:end)) / dx];
end

