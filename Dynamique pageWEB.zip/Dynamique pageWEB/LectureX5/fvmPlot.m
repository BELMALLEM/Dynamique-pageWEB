function fvmPlot(t,p,u)
    n = length(u);
    tris = reshape(1:n*3, n, 3);
    x = p(1, reshape(t(1:3,:)', 3*n, 1));
    y = p(2, reshape(t(1:3,:)', 3*n, 1));
    uu = repmat(reshape(u, n, 1), 1, 3);    
    trisurf(tris, x, y, uu);
end

