clear e;
global itri normal area triCenter
[itri, normal, area, triCenter, e] = extractEdges(p, t);

function [itri, normal, area, triCenter, e] = extractEdges(p, t)
%  Inputs p, t have the same format as exported from the PDE toolbox:
%       p(1,:) are the x coordinates
%       p(2,:) are the x coordinates
%       t(1,:), t(2,:) and t(3,:) are the p-indices of the triangle vertices.
%
%   Output e, itri
%       e(:,1), e(:,2) are indices in the p array for all edges
%       itri(:,1), itri(:,2) are indices in the t array on the left and right
%           of all edges. When itri(:,1)==itri(:,2), the edge is on the
%           boundary.
    side1 = p(:,t(1,:)) - p(:,t(2,:));
    side2 = p(:,t(2,:)) - p(:,t(3,:));
    area = abs(dot(side1, [0 1; -1 0] * side2, 1)) / 2;

    % pick out edges from triangle sides
    allEdges = sort([t(1:2,:), t(2:3,:), t([1,3],:)], 1)';
    [e1, ia1, ~] = unique(allEdges, 'rows', 'first');
    [e2, ia2, ~] = unique(allEdges, 'rows', 'last');
    assert(sum(sum(e1 ~= e2)) == 0);
    e = e1;

    % find corresponding triangles
    itri = mod([ia1, ia2] - 1, size(t,2)) + 1;
    % itri = [floor((ia1 + 2) / 3), floor((ia2 + 2) / 3)];

    % find which side the triangles are and switch end points to make sure
    % that normal points from itri(:,1) to itri(:,2) 
    normal = ([0 1; -1 0] * (p(:,e(:,2)) - p(:,e(:,1))))';
    triCenter = (p(:,t(1,:)) + p(:,t(2,:)) + p(:,t(3,:)))' / 3;
    dpTri1 = p(:,e(:,1)) - triCenter(itri(:,1),:)';
    cp = dot(normal', dpTri1, 1);
    e(cp < 0,:) = e(cp < 0, 2:-1:1);
    normal(cp < 0,:) = -normal(cp < 0,:);
    
    % arrange boundary edges to the top of the array
    ibnd = (itri(:,1) == itri(:,2));
    iint = (itri(:,1) ~= itri(:,2));
    e = [e(ibnd,:); e(iint,:)];
    itri = [itri(ibnd,:); itri(iint,:)];    
    normal = [normal(ibnd,:); normal(iint,:)];
end