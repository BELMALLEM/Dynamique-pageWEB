function dudt = ddtburgers(~,u)
    n = length(u);
    dx = 1/n;
    F = u.^2 / 2;
    dFdu = u;
    nu = abs(dFdu) * dx / 2 * 0.5;
    nu_interface = max(nu(1:end-1), nu(2:end));
    F_interface = 0.5* (F(1:end-1) + F(2:end)) + ...
        nu_interface.* (u(1:end-1) - u(2:end)) / dx;
    F_interface = [0; F_interface; 0];
    dudt = (F_interface(1:end-1) - F_interface(2:end)) / dx;
end

