function dudt = ddtshallow2d(~,u)
    global normal area itri;
    g = 9.8;
    n = length(u) / 3;
    dx = 1/n;
    h = u(1:n);
    vx = u(n+1:2*n) ./ h;
    vy = u(2*n+1:end) ./ h;
    Fx = [h.*vx, h.*vx.^2 + h.^2/2*g, h.*vx.*vy];
    Fy = [h.*vy, h.*vx.*vy, h.*vy.^2 + h.^2/2*g];
    dudt = zeros(n,3);
    for i = 1:size(normal, 1)
        itri1 = itri(i,1);
        itri2 = itri(i,2);
        nx = normal(i,1);
        ny = normal(i,2);
        if itri1 == itri2
            F_interface = [0, h(itri1).^2 / 2 * g * nx, ...
                              h(itri1).^2 / 2 * g * ny];
        else
            nuL = (abs(nx * vx(itri1) + ny * vy(itri1)) + sqrt(g*h(itri1))) / 2;
            nuR = (abs(nx * vx(itri2) + ny * vy(itri2)) + sqrt(g*h(itri2))) / 2;
            nu = max(nuL, nuR);
            uL = [u(itri1), u(itri1+n), u(itri1+2*n)];
            uR = [u(itri2), u(itri2+n), u(itri2+2*n)];
            F_interface = (Fx(itri1,:) + Fx(itri2,:)) / 2 * nx ...
                        + (Fy(itri1,:) + Fy(itri2,:)) / 2 * ny ...
                        + nu * (uL - uR);
        end
        dudt(itri1,:) = dudt(itri1,:) - F_interface / area(itri1);
        dudt(itri2,:) = dudt(itri2,:) + F_interface / area(itri2);
    end
    dudt = dudt(:);
end

